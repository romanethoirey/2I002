import java.util.ArrayList;

public class ListeFILO extends Liste {
	
	public Object pop(){
		return liste.remove(liste.size()-1);
		}

}	
