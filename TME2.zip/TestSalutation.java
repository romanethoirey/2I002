public class TestSalutation {
	public static void main(String [] args){
		Salutation s1 = new Salutation();
		//affiche le message du premier constructuer 
		Salutation s2 = new Salutation("je suis Romane");
		//affiche le message du 2eme constructeur 
		Salutation s3 = new Salutation();
	}
}
