public class Salutation {
	public Salutation() {
		System.out.println("Appel au constructeur sans paramètre ");
	}
	public Salutation (String c){
		System.out.println(c);
	}

}
