
public class TestPoint {

	//public static void main(String[] args) {
		
		Point p1 = new Point (-10,10);
		Point p2 = new Point();
		System.out.println(p2);
		Point p3=p1.addition(p2);
		System.out.println(p3);
		Point p4 = p2.soustraction(p1);
		System.out.println(p4);
		Point p5=p3.signe();
		System.out.println(p5);
		
		System.out.println(p2.equals(p5));
		
	}

}
