public class TestSuiteNewton {
	public static void main (String[] args){
		SuiteNewton e1 = new SuiteNewton(0.1);
	
	}
}
